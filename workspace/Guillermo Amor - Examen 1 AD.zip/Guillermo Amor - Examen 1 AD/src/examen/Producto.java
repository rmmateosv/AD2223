package examen;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement
@XmlType
public class Producto {

	private int id; //4B
	private String nombre; //60B (30 caracteres)
	private int stock; //4B
	
	//
	private int vendido;
	private float recaudado;
	
	public int getVendido() {
		return vendido;
	}

	public void setVendido(int vendido) {
		this.vendido = vendido;
	}

	public float getRecaudado() {
		return recaudado;
	}

	public void setRecaudado(float recaudado) {
		this.recaudado = recaudado;
	}

	public Producto() {}

	public Producto(int id, String nombre, int stock) {
		this.id = id;
		this.nombre = nombre;
		this.stock = stock;
	}
	
	public void mostrar() {
		System.out.println("Id: "+id+
						   "\tNombre: " +nombre+
						   "\tStock: " +stock);
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getStock() {
		return stock;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}
}
