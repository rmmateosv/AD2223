package examen;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.RandomAccessFile;
import java.util.ArrayList;

public class AD {
	
	private String nombreFTxt = "ventas.txt";
	private String nombreFObj = "ventas.obj";
	private String nombreFBin = "stock.bin";
	private String nombreTmp = "ventas.tmp";
	
	public AD() {}
	
	public ArrayList<Venta> obtenerVentasTxt() {
		ArrayList<Venta> resultado = new ArrayList<>();
		
		// Leemos el fichero de texto con un bufferedreader
		BufferedReader f = null;
		
		try {
			f = new BufferedReader(new FileReader(nombreFTxt));
			String campos[];
			String linea;
			
			while((linea = f.readLine()) != null) {
				// separamos los campos en un array
				campos = linea.split(";");
				
				int idProducto = Integer.parseInt(campos[0]);
				// Nos saltamos el campos[1] que es la fecha
				int cant = Integer.parseInt(campos[2]);
				float importe = Float.parseFloat(campos[3]);
				Venta v = new Venta(idProducto, cant, importe);
				resultado.add(v);
			}
			
		} catch (FileNotFoundException e) {
			System.out.println("Error, no se encuentra el fichero de texto");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			if(f != null) {
				try {
					f.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		return resultado;
	}

	public Venta obtenerVentaObj(int idProducto) {
		Venta resultado = null;
		
		ObjectInputStream f = null;
		
		try {
			f = new ObjectInputStream(new FileInputStream(nombreFObj));
			
			while(true) {
				Venta v = new Venta();
				v = (Venta) f.readObject();
				
				// comprobamos si es la venta que buscamos
				if(v.getIdProducto() == idProducto) {
					// Devolvemos true
					resultado = v;
					return resultado;
				}
			}
			
		} catch (EOFException e) {
			// fin
		} catch (FileNotFoundException e) {
			// No hay ventas -> no existe el fichero
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			if(f != null) {
				try {
					f.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		return resultado;
	}

	public boolean modificarVentaObj(Venta v) {
		boolean resultado = false;
		
		ObjectInputStream fO = null;
		ObjectOutputStream fTmp = null;
		
		try {
			fO = new ObjectInputStream(new FileInputStream(nombreFObj));
			fTmp = new ObjectOutputStream(new FileOutputStream(nombreTmp, false));
			
			while(true) {
				Venta venta = new Venta();
				venta = (Venta) fO.readObject();
				
				if(v.getIdProducto() == venta.getIdProducto()) {
					// Modificamos la cantidad y el importe
					venta.setCantidadVendida(venta.getCantidadVendida() + v.getCantidadVendida());
					venta.setImporteRecaudado(venta.getImporteRecaudado() + v.getImporteRecaudado());
				}
				
				fTmp.writeObject(venta);
			}
			
		} catch (EOFException e) {
			
		}catch (FileNotFoundException e) {
			System.out.println("No se encontró el fichero");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			if (fO != null) {
				try {
					fO.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if (fTmp != null) {
				try {
					fTmp.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		File fOriginal = new File(nombreFObj);
		if (fOriginal.delete()) {
			File fTemp = new File(nombreTmp);
			if (fTemp.renameTo(fOriginal)) {
				resultado = true;
			} else {
				System.out.println("Error al renombrar " + nombreTmp);
			}
		} else {
			System.out.println("Error al borrar " + nombreFObj);
		}
		
		return resultado;
	}

	public boolean añadirVentaObj(Venta v) {
		boolean resultado = false;
		
		ObjectOutputStream f = null;
		
		try {
			File fichero = new File(nombreFObj);
			if (fichero.exists()) {
				// Abro con MiObject para que no escriba cabecera
				f = new MiObjectOutputStream(new FileOutputStream(nombreFObj, true));
			} else {
				// Abro con Object para que sí escriba cabecera
				f = new ObjectOutputStream(new FileOutputStream(nombreFObj, true));
			}
			
			// Añadimos la venta al fichero y ponemos el resultado a true
			f.writeObject(v);
			resultado = true;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			if(f != null) {
				try {
					f.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		return resultado;
	}

	public ArrayList<Venta> obtenerVentasObj() {
		ArrayList<Venta> resultado = new ArrayList<>();
		
		ObjectInputStream f = null;
		
		try {
			f = new ObjectInputStream(new FileInputStream(nombreFObj));
			
			while(true) {
				Venta v = new Venta();
				v = (Venta) f.readObject();
				resultado.add(v);
			}
			
		} catch (EOFException e) {
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			if(f != null) {
				try {
					f.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		return resultado;
	}

	public boolean añadirProductosBin(ArrayList<Producto> prods) {
		boolean resultado = false;
		
		DataOutputStream f = null;
		
		try {
			f = new DataOutputStream(new FileOutputStream(nombreFBin, false));
			
			for(Producto p: prods) {
				f.writeInt(p.getId());
			
				StringBuffer sb = new StringBuffer(p.getNombre());
				sb.setLength(30);
				f.writeChars(sb.toString());
			
				f.writeInt(p.getStock());
			}
			resultado = true;
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			if(f != null) {
				try {
					f.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		return resultado;
	}

	public ArrayList<Producto> obtenerProductosBin() {
		ArrayList<Producto> resultado = new ArrayList<Producto>();
		
		DataInputStream f = null;
		
		try {
			f = new DataInputStream(new FileInputStream(nombreFBin));
			
			while(true) {
				Producto p = new Producto();
				
				p.setId(f.readInt());
				
				String nombre = "";
				for(int i = 0; i < 30; i++) {
					nombre += f.readChar();
				}
				p.setNombre(nombre.trim());
				
				p.setStock(f.readInt());
				
				resultado.add(p);
			}
			
		} catch (EOFException e) {
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			if(f != null) {
				try {
					f.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		return resultado;
	}

	public Producto obtenerProducto(int id) {
		Producto resultado = null;
		
		RandomAccessFile f = null;
		
		try {
			f = new RandomAccessFile(nombreFBin, "r");
			
			while(true) {
				int idProd = f.readInt();
				
				if(id == idProd) {
					// Modificar stock
					resultado.setId(idProd);
					
					String nombre = "";
					for(int i = 0; i < 30; i++) {
						nombre += f.readChar();
					}
					resultado.setNombre(nombre.trim());
					
					resultado.setStock(f.readInt());
					
					return resultado;
				}
				
				f.seek(f.getFilePointer() + 64);
			}
			
		} catch (EOFException e) {
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			if(f != null) {
				try {
					f.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		return resultado;
	}

	public boolean modificarStock(Producto p, int nStock) {
		boolean resultado = false;
		
		RandomAccessFile f = null;
		
		try {
			f = new RandomAccessFile(nombreFBin, "rw");
			
			while(true) {
				int id = f.readInt();
				if (id == p.getId()) {
					// Nos posicionamos en el stock
					f.seek(f.getFilePointer()+60);
					
					f.writeInt(nStock);
					
					return true;
				} else {
					
					f.seek(f.getFilePointer() + 64);
				}
			}
			
		} catch (EOFException e) {
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			if(f != null) {
				try {
					f.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		return resultado;
	}
	
	
	
}
