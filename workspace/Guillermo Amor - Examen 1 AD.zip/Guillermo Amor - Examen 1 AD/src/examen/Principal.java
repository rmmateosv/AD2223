package examen;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Scanner;

public class Principal {
	static Scanner t = new Scanner(System.in);
	static SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
	
	static AD fAcceso = new AD();
	
	public static void main(String[] args) {
		int opcion;
		do {
			System.out.println("Introduce opción:");
			System.out.println("0-Salir");	
			System.out.println("1-Crear fichero de objetos");
			System.out.println("2-Crear Fichero binario de productos");
			System.out.println("3-Modificar stock de un producto");
			System.out.println("4-Generar xml de un producto");
			System.out.print("Introduce una opción: ");
			opcion = t.nextInt(); t.nextLine();
			switch(opcion) {
			case 1:
				crearFicheroObjetos();
				break;
			case 2:
				crearFicheroBinario();
				break;
			case 3:
				modificarStock();
				break;
			case 4:
				crearXML();
				break;
			}
		}while(opcion!=0);
	}

	private static void crearXML() {
		ArrayList<Producto> productos = fAcceso.obtenerProductosBin();
		for(Producto pr: productos) {
			pr.mostrar();
		}
		System.out.print("Introduce el id: ");
		int id = t.nextInt(); t.nextLine();
		
		Producto p = fAcceso.obtenerProducto(id);
		
		if(p != null) {
			// generamos
			
		}
		else {
			System.out.println("Error, el id no coincide con ningún producto");
		}
	}

	private static void modificarStock() {
		// Mostramos los productos
		ArrayList<Producto> productos = fAcceso.obtenerProductosBin();
		for(Producto pr: productos) {
			pr.mostrar();
		}
		System.out.print("Introduce el id: ");
		int id = t.nextInt(); t.nextLine();
		
		Producto p = fAcceso.obtenerProducto(id);
		
		if(p != null) {
			// existe seguimos
			System.out.print("Introduce nuevo stock: ");
			int nStock = t.nextInt(); t.nextLine();
			
			if(fAcceso.modificarStock(p, nStock)) {
				System.out.println("Stock modificado");
			}
			else {
				System.out.println("Error al modificar el stock");
			}
			
		}
		else {
			System.out.println("Error, el id no coincide con ningún producto");
		}
	}

	private static void crearFicheroBinario() {
		// Obtenemos las ventas --> contienen el ID de los productos
		ArrayList<Venta> ventasObj = fAcceso.obtenerVentasObj();
		ArrayList<Producto> prods = new ArrayList<>();
		
		// Por cada producto, pedimos nombre y stock
		for(Venta v: ventasObj) {
			System.out.println("Id producto: " + v.getIdProducto());
			
			System.out.print("Introduce el nombre para el producto "+v.getIdProducto()+": ");
			String nombre = t.nextLine();
			
			System.out.print("Introduce el stock para el producto "+v.getIdProducto()+": ");
			int stock = t.nextInt(); t.nextLine();
			
			Producto p = new Producto(v.getIdProducto(), nombre, stock);
			prods.add(p);
		}
		
		if(fAcceso.añadirProductosBin(prods)) {
			ArrayList<Producto> productos = fAcceso.obtenerProductosBin();
			for(Producto pr: productos) {
				pr.mostrar();
			}
		}
		else {
			System.out.println("Problema al añadir los productos al binario");
		}
	}

	private static void crearFicheroObjetos() {
		// Obtener las ventas (HAY REPETIDAS)
		ArrayList<Venta> ventas = fAcceso.obtenerVentasTxt();
		
		// Recorremos la lista
		for(Venta v: ventas) {
			Venta ven = fAcceso.obtenerVentaObj(v.getIdProducto());
			
			if(ven != null) {
				// Ya está en el fichero de objetos
				if(fAcceso.modificarVentaObj(v)) {
					System.out.println("1 Venta actualizada");
				}
				else {
					System.out.println("Error al actualizar una venta");
				}
			}
			else {
				// No está en el fichero
				// Lo añadimos
				if(fAcceso.añadirVentaObj(v)) {
					System.out.println("1 Venta añadida.");
				}
				else {
					System.out.println("Error al añadir una venta");
				}
			}
		}
		
		ArrayList<Venta> ventasObj = fAcceso.obtenerVentasObj();
		System.out.println("\nVENTAS:");
		for(Venta v: ventasObj) {
			v.mostrar();
		}
	}

}
