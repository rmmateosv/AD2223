package examen;

import java.io.Serializable;

public class Venta implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4115703701641065365L;
	private int idProducto; //4B
	private int cantidadVendida; //4B
	private float importeRecaudado; //4B
	
	public Venta() {}

	public Venta(int idProducto, int cantidadVendida, float importeRecaudado) {
		this.idProducto = idProducto;
		this.cantidadVendida = cantidadVendida;
		this.importeRecaudado = importeRecaudado;
	}
	
	public void mostrar() {
		System.out.println("Id de producto: " +idProducto+
						   "\tCantidad vendida: "+cantidadVendida+
						   "\tImporte recaudado: "+importeRecaudado);
	}
	
	public int getIdProducto() {
		return idProducto;
	}

	public void setIdProducto(int idProducto) {
		this.idProducto = idProducto;
	}

	public int getCantidadVendida() {
		return cantidadVendida;
	}

	public void setCantidadVendida(int cantidadVendida) {
		this.cantidadVendida = cantidadVendida;
	}

	public float getImporteRecaudado() {
		return importeRecaudado;
	}

	public void setImporteRecaudado(float importeRecaudado) {
		this.importeRecaudado = importeRecaudado;
	}
	
}
